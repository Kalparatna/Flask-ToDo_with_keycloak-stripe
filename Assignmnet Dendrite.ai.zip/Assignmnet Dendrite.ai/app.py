import os
from flask import Flask, redirect, url_for, session, request, render_template, jsonify
import requests
import logging
from dotenv import load_dotenv
from flask_sqlalchemy import SQLAlchemy
from flask_graphql import GraphQLView
import graphene
import stripe

load_dotenv()

STRIPE_SECRET_KEY = os.getenv('STRIPE_SECRET_KEY')
STRIPE_PUBLIC_KEY = os.getenv('STRIPE_PUBLIC_KEY')

stripe.api_key = STRIPE_SECRET_KEY

app = Flask(__name__)

app.secret_key = os.getenv('FLASK_SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
logging.basicConfig(level=logging.DEBUG)

keycloak_server_url = os.getenv('KEYCLOAK_SERVER_URL')
realm_name = os.getenv('REALM_NAME')
client_id = os.getenv('CLIENT_ID')
client_secret = os.getenv('CLIENT_SECRET')
redirect_uri = os.getenv('REDIRECT_URI')

class ToDo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)
    description = db.Column(db.Text, nullable=False)
    time = db.Column(db.String(20), nullable=False)

class ToDoType(graphene.ObjectType):
    id = graphene.Int()
    title = graphene.String()
    description = graphene.String()
    time = graphene.String()

class Query(graphene.ObjectType):
    todos = graphene.List(ToDoType)

    def resolve_todos(self, info):
        return ToDo.query.all()

class CreateToDoMutation(graphene.Mutation):
    class Arguments:
        title = graphene.String(required=True)
        description = graphene.String(required=True)
        time = graphene.String(required=True)

    todo = graphene.Field(ToDoType)

    def mutate(self, info, title, description, time):
        new_todo = ToDo(title=title, description=description, time=time)
        db.session.add(new_todo)
        db.session.commit()
        return CreateToDoMutation(todo=new_todo)

class Mutation(graphene.ObjectType):
    create_todo = CreateToDoMutation.Field()

schema = graphene.Schema(query=Query, mutation=Mutation)


@app.route('/login')
def login():
    authorize_url = f"{keycloak_server_url}/realms/{realm_name}/protocol/openid-connect/auth"
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'openid profile email'
    }
    return redirect(f"{authorize_url}?{'&'.join([f'{key}={value}' for key, value in params.items()])}")

@app.route('/callback')
def callback():
    code = request.args.get('code')
    logging.debug(f"Callback received with code: {code}")

    token_endpoint = f"{keycloak_server_url}/realms/{realm_name}/protocol/openid-connect/token"
    payload = {
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri,
        'client_id': client_id,
        'client_secret': client_secret
    }

    try:
        response = requests.post(token_endpoint, data=payload)
        token_data = response.json()

        if 'access_token' in token_data:
            userinfo_endpoint = f"{keycloak_server_url}/realms/{realm_name}/protocol/openid-connect/userinfo"
            userinfo_response = requests.get(userinfo_endpoint, headers={'Authorization': f"Bearer {token_data['access_token']}"} )
            userinfo = userinfo_response.json()

            session['user'] = {
                'id_token': token_data.get('id_token'),
                'access_token': token_data.get('access_token'),
                'refresh_token': token_data.get('refresh_token'),
                'username': userinfo.get('preferred_username'),
                'email': userinfo.get('email')
            }

            logging.debug("User logged in successfully.")
            return redirect(url_for('index'))
        else:
            logging.error("Failed to fetch tokens.")
            return "Failed to fetch tokens."

    except Exception as e:
        logging.error(f"Exception during token exchange: {e}")
        return "Failed to fetch tokens."

@app.route('/logout')
def logout():
    logging.debug('Attempting to logout...')
    try:
        end_session_endpoint = f"{keycloak_server_url}/realms/{realm_name}/protocol/openid-connect/logout"
        response = requests.get(f"{end_session_endpoint}?redirect_uri={redirect_uri}", timeout=5)

        session.clear()  
        logging.debug('Session cleared. Redirecting to login...')
        return redirect(url_for('login'))

    except requests.exceptions.RequestException as e:
        logging.error(f"Exception during logout: {e}")
        return "Failed to logout. Please try again."

@app.route('/')
def index():
    if 'user' in session:
        todos = ToDo.query.all()
        return render_template('home.html', username=session['user']['username'], todos=todos)
    else:
        return redirect(url_for('login'))

@app.route('/add_todo', methods=['POST'])
def add_todo():
    if 'user' not in session:
        return redirect(url_for('login'))

    title = request.form['title']
    description = request.form['description']
    time = request.form['time']
    new_todo = ToDo(title=title, description=description, time=time)
    db.session.add(new_todo)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/edit_todo/<int:id>', methods=['GET', 'POST'])
def edit_todo(id):
    if 'user' not in session:
        return redirect(url_for('login'))

    todo = ToDo.query.get(id)
    if request.method == 'POST':
        todo.title = request.form['title']
        todo.description = request.form['description']
        todo.time = request.form['time']
        db.session.commit()
        return redirect(url_for('index'))

    return render_template('edit_todo.html', todo=todo)


@app.route('/delete_todo/<int:id>', methods=['POST'])
def delete_todo(id):
    if 'user' not in session:
        return redirect(url_for('login'))

    todo = ToDo.query.get(id)
    if todo:
        db.session.delete(todo)
        db.session.commit()
    return redirect(url_for('index'))

app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

@app.route('/buy_pro', methods=['GET'])
def buy_pro():
    if 'user' not in session:
        return redirect(url_for('login'))

    stripe_session = stripe.checkout.Session.create(  
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {
                    'name': 'Pro License',
                },
                'unit_amount': 4999,  
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url=url_for('payment_success', _external=True),
        cancel_url=url_for('payment_cancel', _external=True),
    )
    return redirect(stripe_session.url, code=303)

@app.route('/payment_success')
def payment_success():
    if 'user' in session:
        session['pro_user'] = True  

    return render_template('payment_success.html', message="Thank you for purchasing the Pro License!")


@app.route('/payment_cancel')
def payment_cancel():
    return render_template('payment_cancel.html', message="Your payment was canceled.")



if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables
    app.run(debug=True)
